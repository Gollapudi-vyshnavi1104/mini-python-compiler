# Mini-Python-Compiler-in-Lex-and-Yacc
A Mini Compiler for Python, that parses the If-Else and While constructs, developed using Lex and Yacc

## Grammar
![alt text](https://github.com/Kadle11/Mini-Python-Compiler-in-Lex-and-Yacc/blob/master/Grammar.png)


